package com.ky.demo.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ky.demo.util.PostData;
import com.ky.demo.util.PropertiesUtil;

/**
 * Servlet implementation class APIServlet
 */
@WebServlet(description = "测试Servlet", urlPatterns = { "/api" })
public class APIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String agent = PropertiesUtil.getValue("agent").toString();
	private static final String linecode = PropertiesUtil.getValue("linecode").toString();	
	private static final String md5 = PropertiesUtil.getValue("md5").toString();
	private static final String des = PropertiesUtil.getValue("des").toString();
	private static final String url = PropertiesUtil.getValue("url").toString();
	private static final String getRecordUrl = PropertiesUtil.getValue("getRecordUrl").toString();


	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public APIServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			String s = request.getParameter("s").isEmpty() ? "0" : request.getParameter("s");
			String account = request.getParameter("account").isEmpty() ? "test0001" : request.getParameter("account");
			String orderId = request.getParameter("orderId").isEmpty() ? agent + df.format(new Date()) + account : request.getParameter("orderId");
			String money = request.getParameter("money").isEmpty() ? "0" : request.getParameter("money");
			String apiUrl = url;
			int key = Integer.parseInt(s);
			switch (key) {
				case 0:					
					String ip = getIp(request);					
					response.getWriter().append(PostData.game(agent, account, money, orderId, des, md5, apiUrl, ip, linecode));
					break;
				case 1:
					response.getWriter().append(PostData.getBalance(agent, account,  des, md5, apiUrl));
					break;
				case 2:
					response.getWriter().append(PostData.sf(agent, account, money, orderId, des, md5, apiUrl));
					break;
				case 3:
					response.getWriter().append(PostData.xiafen(agent, account, money, orderId, des, md5, apiUrl));
					break;
				case 4:
					response.getWriter().append(PostData.getOrder(agent, orderId, des, md5, apiUrl));
					break;
				case 5:
					response.getWriter().append(PostData.getState(agent, account, des, md5, apiUrl));
					break;
				case 6:
					apiUrl = getRecordUrl;
					df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String startTime = request.getParameter("startTime").isEmpty() ? df.format(new Date()) : request.getParameter("startTime");
					String endTime = request.getParameter("endTime").isEmpty() ? df.format(new Date()) : request.getParameter("endTime");
					startTime = df.parse(startTime).getTime()+"";
					endTime = df.parse(endTime).getTime()+"";
					response.getWriter().append(PostData.getRecord(agent, startTime,endTime, des, md5, apiUrl));
					break;
				case 7:
					response.getWriter().append(PostData.getAllBalance(agent, account,  des, md5, apiUrl));
					break;
				case 8:
					response.getWriter().append(PostData.kick(agent, account,  des, md5, apiUrl));
					break;
				default:
					break;
			}
		} catch (Exception e) {
			response.getWriter().append("{\"code\":-1,\"msg\":\""+e.getMessage().replace("\"", "'")+"\"}");
		}		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	/**
	 * 获取客户端请求的真实ip地址
	 * @param request 请求对象
	 * @return String 客户端请求ip
	 */
	public static String getIp(HttpServletRequest request){
	    String ip = request.getHeader("x-forwarded-for"); 
	    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	      ip = request.getHeader("Proxy-Client-IP"); 
	    } 
	    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	      ip = request.getHeader("WL-Proxy-Client-IP"); 
	    } 
	    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	      ip = request.getHeader("HTTP_CLIENT_IP"); 
	    } 
	    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	      ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
	    } 
	    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	      ip = request.getRemoteAddr(); 
	    }
		if (ip.contains(",")){
			ip = ip.split(",")[0];
		};
		return ip;
	} 

}
