
## ubuntu 1604 install:

```
apt install nginx nginx-extras php7.0-fpm php7.0-curl php7.0-mcrypt
```

## nginx config:

```
user www-data;
worker_processes auto;
pid /run/nginx.pid;

events {
	worker_connections  4096;
}

http {
	server {
		listen 80 default_server;
		listen [::]:80 default_server;

		root /var/www/html;
		index index.php index.html index.htm index.nginx-debian.html;

		server_name _;

		location / {
			try_files $uri $uri/ =404;
		}

		location ~ \.php$ {
			include snippets/fastcgi-php.conf;
			fastcgi_pass unix:/var/run/php/php7.0-fpm.sock;
		}

		location ~ (\.htaccess|\.inc|\.tpl|\.sql|\.db)$ {
			deny all;
		}
	}
}
```

## restart service:
```
systemctl restart nginx 
systemctl restart php7.0-fpm
```

## configuration:

Edit config.php file

```php
define( 'DEBUG', true);
define( 'LOG_IDENT', 'ident-api');

define( 'agent', '10000');
define( 'desKey', '3b306586de7ac209');
define( 'md5Key', 'f95342f880b2614e');
define( 'apiUrl', 'https://your.api.com:99/channelHandle');
define( 'recordUrl', 'https://your.api.com:98/getRecordHandle');
define( 'lineCode', 'demo1');
```


