<?php
/*****************************
api configurations
*/
define( 'DEBUG', true);
define( 'LOG_IDENT', 'leg-api');

define( 'agent', '10021');//代理编号
define( 'desKey', '8b19c070be984f0a');//DES密钥
define( 'md5Key', '3fb134453b8b49eb');//MD5密钥
define( 'apiUrl', 'https://legapi.ledingnet.com:189/channelHandle');//api接口URL
define( 'recordUrl', 'https://legrec.ledingnet.com:190/getRecordHandle');//拉单独立接口URL
define( 'lineCode', 'lc10021');//linecode，格式lc+代理编号

