<?php

require_once 'config.php';
require_once 'utils.php';

function main()
{
	dbglog('php version: ' . phpversion());
	dbglog(get_param());

	$s = get_param('s');
	$account = get_param('account');
	$money = get_param('money');
	$timestamp = microtime_int();
	$time_str = timestamp_str('YmdHis', 'Asia/Chongqing');
	$ip = get_ip();
	$orderId = get_param('orderId');
	$orderId || ($orderId = agent . $time_str . $account);

	dbglog('client ip addr: ' . $ip);
	dbglog('account: ' . $account);
	dbglog('orderId: ' . $orderId);

	$param = null;

	switch($subCmd = intval($s)) {
		case 0: // login
			$param = http_build_query(array(
				's' => $s,
				'account' => $account,
				'money' => $money,
				'lineCode' => lineCode,
				'ip' => $ip,
				'orderid' => $orderId,
				'lang' => 'zh-CN'
			));
			break;
		case 1: // query the money of account
		case 5: // check if the account is online
		case 7: // query the game's total coin or money 
		case 8: // force one player offline
			$param = http_build_query(array(
				's' => $s,
				'account' => $account
			));
			break;
		case 2: // charge the money of account
		case 3: // withdraw the money of account
			$param = http_build_query(array(
				's' => $s,
				'account' => $account,
				'orderid' => $orderId,
				'money' => $money,
				'ip' => $ip
			));
			break;
		case 4: // query the order info by id 
			$param = http_build_query(array(
				's' => $s,
				'orderid' => $orderId,
			));
			break;
		case 6: // query game scores 
			$param = http_build_query(array(
				's' => $s,
				'startTime' => get_param('startTime'),
				'endTime' => get_param('endTime')
			));
			break;

	}

	dbglog('parma: '.$param);

	$url = ($subCmd!=6)? apiUrl : recordUrl;
	$url .= '?' . http_build_query(array(
		'agent' => agent,
		'timestamp' => $timestamp,
		'param' => desEncode(desKey, $param),
		'key' => md5(agent.$timestamp.md5Key)
	));

	dbglog('request: '.$url);

	$res = curl_get_content($url);

	dbglog('curl_get_content: '.json_encode($res));

	return $res;
}


/*****************************
process framework 
*/

try {
	ob_start();
	openlog(LOG_IDENT, LOG_PID | LOG_PERROR, LOG_LOCAL0);
	$res = main();
	jsonp_nocache($res);

} catch (Exception $e) {
	ob_end_clean();
	syslog(LOG_ERR, $e->getMessage());
	jsonp_nocache(array(
		'm' => 'apiProxy',
		's' => get_param('s'),
		'd' => array(
			'code' => -1,
			'message' => $e->getMessage()
		)
	));
} finally {
	ob_end_flush();
	closelog();
}

