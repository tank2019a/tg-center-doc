﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
namespace Csharp_demo
{
    public class Utils
    {
        #region 检查是否为IP地址
        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static bool IsIP(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");
        }
        #endregion

        #region 获得当前页面客户端的IP
        /// <summary>
        /// 获得当前页面客户端的IP
        /// </summary>
        /// <returns>当前页面客户端的IP</returns>
        public static string GetIP()
        {
            string result = "";
            result = HttpContext.Current.Request.Headers["Cdn-Src-Ip"];
            if (string.IsNullOrEmpty(result))
            {
                result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"]; ;
                if (string.IsNullOrEmpty(result))
                    result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                if (string.IsNullOrEmpty(result))
                    result = HttpContext.Current.Request.UserHostAddress;
                if (string.IsNullOrEmpty(result) || !Utils.IsIP(result))
                    return "127.0.0.1";
            }
            return result;
        }
        #endregion
        #region 构造URL GET请求
        /// <summary>
        /// 获取请求的反馈信息
        /// </summary>
        /// <param name="url">地址</param>
        /// <returns></returns>
        public static string doGetRequest(string url)
        {
            HttpWebRequest hwRequest;
            HttpWebResponse hwResponse;
            string strResult = string.Empty;
            hwRequest = (System.Net.HttpWebRequest)WebRequest.Create(url);
            hwRequest.Timeout = 20 * 1000;
            hwRequest.Method = "GET";
            hwRequest.ContentType = "application/x-www-form-urlencoded;charset=utf-8";

            hwResponse = (HttpWebResponse)hwRequest.GetResponse();
            StreamReader srReader = new StreamReader(hwResponse.GetResponseStream(), Encoding.UTF8);
            strResult = srReader.ReadToEnd();
            srReader.Close();
            hwResponse.Close();

            return strResult;
        }
        //public static string GetXMLDocumentFromWebPage(string url)
        //{
        //    HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(url);
        //    myRequest.Method = "GET";
        //    myRequest.ContentType = "application/x-www-form-urlencoded";
        //    myRequest.Timeout = 100*1000;
        //    myRequest.ContentLength = 0;
        //    // Get response 
        //    HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
        //    StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.Default);
        //    string content = reader.ReadToEnd();
        //    return content;
        //}
        #endregion
        /// <summary>
        /// 转换时间为unix时间戳到毫秒
        /// </summary>
        /// <param name="date">需要传递UTC时间,避免时区误差,例:DataTime.UTCNow</param>
        /// <returns></returns>
        public static double ConvertToUnixOfTime(DateTime time)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1));
            return (long)(time - startTime).TotalMilliseconds;
        }
    }
}