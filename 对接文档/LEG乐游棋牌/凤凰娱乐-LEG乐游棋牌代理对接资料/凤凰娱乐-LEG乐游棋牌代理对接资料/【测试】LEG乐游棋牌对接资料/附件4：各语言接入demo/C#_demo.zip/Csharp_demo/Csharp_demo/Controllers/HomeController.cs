﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
namespace Csharp_demo.Controllers
{
    public class HomeController : Controller
    {
        private string agent = ConfigurationManager.AppSettings["agent"].ToString();
        private string desKey = ConfigurationManager.AppSettings["desKey"].ToString();
        private string md5key = ConfigurationManager.AppSettings["md5key"].ToString();
        private string apiUrl = ConfigurationManager.AppSettings["apiUrl"].ToString();
        private string recordUrl = ConfigurationManager.AppSettings["recordUrl"].ToString();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult testget()
        {
            var result = @"{""msg"":""hello world man""}";
            return Content(result);
        }
        public ActionResult api()
        {
            string result = "";
            try
            {
                int s = Convert.ToInt32(Request["s"]);
                string param = "";
                string ip = Utils.GetIP();
                DateTime time = DateTime.UtcNow.AddHours(8);
                var timestamp = Utils.ConvertToUnixOfTime(time);
                switch (s)
                {
                    case 0://登录接口
                        var account = Request["account"];
                        var money = Request["money"];
                        var orderId = agent + time.ToString("yyyyMMddHHmmss") + account;
                        var lineCode = "demo1";
                        param = "s=" + s + "&account=" + account + "&money=" + money + "&lineCode=" + lineCode + "&ip=" + ip + "&orderid=" + orderId + "&lang=zh-CN";
                        break;
                    case 1://查询玩家可下分余额
                        var account1 = Request["account"];
                        param = "s=" + s + "&account=" + account1;
                        break;
                    case 2://上分
                        var account2 = Request["account"];
                        var money2 = Request["money"];
                        var orderId2 = agent + time.ToString("yyyyMMddHHmmss") + account2;
                        param = "s=" + s + "&account=" + account2 + "&orderid=" + orderId2 + "&money=" + money2 + "&ip=" + ip;
                        break;
                    case 3://下分
                        var account3 = Request["account"];
                        var money3 = Request["money"];
                        var orderId3 = agent + time.ToString("yyyyMMddHHmmss") + account3;
                        param = "s=" + s + "&account=" + account3 + "&orderid=" + orderId3 + "&money=" + money3 + "&ip=" + ip;
                        break;
                    case 4://查询订单状态
                        var orderId4 = Request["orderId"];
                        param = "s=" + s + "&orderid=" + orderId4;
                        break;
                    case 5://查询玩家是否在线
                        var account5 = Request["account"];
                        param = "s=" + s + "&account=" + account5;
                        break;
                    case 6://获取游戏结果数据
                        var startTime = Request["startTime"];
                        var endTime = Request["endTime"];
                        param = "s=" + s + "&startTime=" + startTime + "&endTime=" + endTime;
                        break;
                    case 7://查询游戏总余额
                        var account7 = Request["account"];
                        param = "s=" + s + "&account=" + account7;
                        break;
                    case 8://根据玩家账号踢玩家下线
                        var account8 = Request["account"];
                        param = "s=" + s + "&account=" + account8;
                        break;
                }
                var url = s != 6 ? apiUrl : recordUrl;
                var desParam = Encrypt.AesEncrypt(param, desKey);
                var desMd5 = Encrypt.MD5Encrypt(agent + timestamp + md5key);
                url = url + "?" + "agent=" + agent + "&timestamp=" + timestamp + "&param=" + desParam + "&key=" + desMd5;
                result = Utils.doGetRequest(url);
            }
            catch(Exception ex)
            {
                result=@"{""code"":999,""msg"":"""+ex.Message.Replace("\"", "'").Replace("\\",",") + @"""}";
            }
            return Content(result);
        }
    }
}