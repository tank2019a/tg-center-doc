var httpServer = require("./utils/httpServer");
var app = httpServer.app;
var argv = process.argv.splice(2);
var serverPort = argv[0] ? parseInt(argv[0]) : 3000;//服务器端口号
app.use('/api', require('./routes/api'));
httpServer.createHttpServer(serverPort);