module.exports.agent = "10170";
module.exports.desKey = '4832b190912543df';
module.exports.md5key = "289bba37505b4ee7";
module.exports.apiUrl = "http://10.96.49.102:89/channelHandle";
module.exports.recordUrl = "http://10.96.49.102:89/getRecordHandle";
