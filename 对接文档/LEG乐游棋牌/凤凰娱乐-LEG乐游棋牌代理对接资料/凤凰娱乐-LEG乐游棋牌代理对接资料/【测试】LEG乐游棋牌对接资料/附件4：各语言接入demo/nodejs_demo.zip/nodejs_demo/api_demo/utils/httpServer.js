var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var utils = require('../utils/utils');
//出错是打印出错信息
process.on('uncaughtException', function (err) { utils.error(' Caught exception: ' + err.stack); });
var app = express();
app.use(bodyParser.json({ limit: '100mb' }));//设置post body数据的大小
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true }));
app.use(cookieParser());
//设置资源目录
app.use(express.static(path.join(__dirname, '../public')));
//添加出错引用
function addErrorUse() {
    //请求未找到
    app.use(function (req, res, next) {
        var err = new Error('Not Found');
        err.status = 404;
        next(err);
    });
    //请求出错
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.end(err.message);
    });
}
//创建http服务器
function createHttpServer(port) {
    addErrorUse();
    app.set('port', port);
    var server = app.listen(app.get('port'), function () {
        utils.log('http服务器启动成功,端口号: ' + server.address().port);
    });
}
//创建https服务器
function createHttpsServer(port, keyPath, crtPath) {
    addErrorUse();
    var fs = require('fs');
    var https = require('https');
    var privateKey = fs.readFileSync(keyPath, 'utf8');
    var certificate = fs.readFileSync(crtPath, 'utf8');
    var httpsServer = https.createServer({ key: privateKey, cert: certificate }, app);
    httpsServer.listen(port, function () {
        utils.log('https服务器启动成功,端口号: ' + port);
    });
}
module.exports.app = app;
module.exports.createHttpServer = createHttpServer;//创建http服务器
module.exports.createHttpsServer = createHttpsServer;//创建https服务器

