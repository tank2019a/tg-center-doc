var express = require('express');
var router = express.Router();
var crypto = require("crypto");
var moment = require('moment');
var qs = require('querystring');
var request = require('request');
var utils = require('../utils/utils');
var condfig = require('../config/config');
//代理接口
router.post('/', function (req, res) {
    var s = req.body.s;
    var param = "";
    var ip = utils.getIp(req).replace(/::ffff:/, '');//请求ip
    var time = new moment().utcOffset(8);
    switch (parseInt(s)) {
        case 0://登录接口
            var account = req.body.account;
            var money = req.body.money;
            var orderId = condfig.agent + time.format("YYYYMMDDHHmmss") + account;
            var lineCode = "demo1";
            param = "s=" + s + "&account=" + account + "&money=" + money + "&lineCode=" + lineCode + "&ip=" + ip + "&orderid=" + orderId + "&lang=zh-CN";
            break;
        case 1://查询玩家可下分余额
            var account = req.body.account;
            param = "s=" + s + "&account=" + account;
            break;
        case 2://上分
            var account = req.body.account;
            var money = req.body.money;
            var orderId = condfig.agent + time.format("YYYYMMDDHHmmss") + account;
            param = "s=" + s + "&account=" + account + "&orderid=" + orderId + "&money=" + money + "&ip=" + ip;
            break;
        case 3://下分
            var account = req.body.account;
            var money = req.body.money;
            var orderId = condfig.agent + time.format("YYYYMMDDHHmmss") + account;
            param = "s=" + s + "&account=" + account + "&orderid=" + orderId + "&money=" + money + "&ip=" + ip;
            break;
        case 4://查询订单状态
            var orderId = req.body.orderId;
            param = "s=" + s + "&orderid=" + orderId;
            break;
        case 5://查询玩家是否在线
            var account = req.body.account;
            param = "s=" + s + "&account=" + account;
            break;
        case 6://获取游戏结果数据
            var startTime = req.body.startTime;
            var endTime = req.body.endTime;
            param = "s=" + s + "&startTime=" + startTime + "&endTime=" + endTime
            break;
        case 7://查询游戏总余额
            var account = req.body.account;
            param = "s=" + s + "&account=" + account;
            break;
        case 8://根据玩家账号提玩家下线
            var account = req.body.account;
            param = "s=" + s + "&account=" + account;
            break;
    }
    var timestamp = time.unix() * 1000;
    var url = s != 6 ? condfig.apiUrl : condfig.recordUrl;
    url = url + "?" + qs.stringify({
        agent: condfig.agent,
        timestamp: timestamp,
        param: utils.desEncode(condfig.desKey, param),
        key: crypto.createHash('md5').update(condfig.agent + timestamp.toString() + condfig.md5key).digest('hex'),
    })
    request({ url: url, timeout: 100 * 1000 }, function (error, response, data) {
        res.writeHeader(200, { "Content-Type": "text/plain;charset=utf8" });
        res.end(JSON.stringify(data));
    })
});
module.exports = router;