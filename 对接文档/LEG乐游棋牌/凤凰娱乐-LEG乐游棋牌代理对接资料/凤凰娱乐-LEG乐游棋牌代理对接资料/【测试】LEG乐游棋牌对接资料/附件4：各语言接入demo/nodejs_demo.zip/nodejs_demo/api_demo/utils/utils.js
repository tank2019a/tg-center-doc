var crypto = require("crypto");
var utils = {};
var useConsoleLog = true;
utils.log = function (message) {
    if (useConsoleLog) {
        console.log(message);
    }
}
utils.error = function (error) {
    if (useConsoleLog) {
        console.log(error);
        console.error(error);
    }
}
//DES解密
utils.desDecode = function (desKey, data) {
    var cipherChunks = [];
    var decipher = crypto.createDecipheriv('aes-128-ecb', desKey, '');
    decipher.setAutoPadding(true);
    cipherChunks.push(decipher.update(data, 'base64', 'utf8'));
    cipherChunks.push(decipher.final('utf8'));
    return cipherChunks.join('');
}
//DES加密
utils.desEncode = function desEncode(desKey, data) {
    var cipherChunks = [];
    var cipher = crypto.createCipheriv('aes-128-ecb', desKey, '');
    cipher.setAutoPadding(true);
    cipherChunks.push(cipher.update(data, 'utf8', 'base64'));
    cipherChunks.push(cipher.final('base64'));

    return cipherChunks.join('');
}
//响应数据消息
utils.resEnd = function (res, data) {
    var code = data.d ? data.d.code : data.code;
    utils.log("服务器响应： code：" + code);
    res.writeHeader(200, { "Content-Type": "text/plain;charset=utf8" });
    res.end(JSON.stringify(data));
}
//获取ip
utils.getIp = function (req) {
    var ip = req.headers['x-real-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';
    var ips = ip.split(',');
    if (ips.length > 0) {
        ip = ips[0];
    }
    return ip;
};
module.exports = utils;